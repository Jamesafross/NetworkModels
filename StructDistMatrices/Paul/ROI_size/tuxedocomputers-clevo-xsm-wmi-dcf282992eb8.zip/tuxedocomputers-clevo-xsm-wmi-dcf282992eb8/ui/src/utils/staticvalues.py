PROGRAM_NAME = "tuxedo-wmi-ui"
KERNEL_MODULE_NAME = "clevo_xsm_wmi"